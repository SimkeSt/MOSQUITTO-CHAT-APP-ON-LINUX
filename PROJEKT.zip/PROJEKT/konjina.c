#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() 
{
  char spika[20];
  char user[100];
  char msg[20];
  char chat[15];
  char mess[100];
  int gotovo = 1;
  char izlaz[] = "->exit";
  reset:
  printf("Choose a topic\n");
  scanf("%s", spika);
  sprintf(chat, "gnome-terminal -- ./beginChat.sh %s", spika);
  system(chat);
  printf("Choose your username\n");
  scanf("%s", user);
  printf("Start chatting:\n");
  strcat(user," ");
  strcat(user,msg);
  
  do {
    scanf("%s", msg);
    sprintf(mess, "./publishMessage.sh %s %s", spika, user);
    system(mess);
    if (strcmp(msg, izlaz) == 0) {
      goto reset;
      }
   } 
  while (gotovo = 1);
   return 0;
}
